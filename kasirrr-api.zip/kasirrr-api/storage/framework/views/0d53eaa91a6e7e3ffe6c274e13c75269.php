  <div class="simple-footer">
      Copyright &copy; SKUY <?= date('Y') ?>
  </div>
<?php /**PATH /Users/izzamasss/Documents/work/skuy-project/skuy-api/resources/views/components/auth-footer.blade.php ENDPATH**/ ?>