<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; <?= date('Y') ?> <div class="bullet"></div> Design By SKUY
    </div>
    <div class="footer-right">
        1.0.0
    </div>
</footer>
<?php /**PATH /Users/izzamasss/Documents/work/skuy-project/skuy-api/resources/views/components/footer.blade.php ENDPATH**/ ?>