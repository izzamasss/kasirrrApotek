  <div class="simple-footer">
      Copyright &copy; JAGOFLUTTER 2024
  </div>
<?php /**PATH /Users/izzamasss/Documents/course/codewithbahri/fic14-custom/laravel-posresto-backend-jilid2/resources/views/components/auth-footer.blade.php ENDPATH**/ ?>