 <div class="login-brand">
     <img src="<?php echo e(asset('img/logo-jf.png')); ?>" alt="logo" width="100" class="shadow-light rounded-circle">
 </div>
<?php /**PATH /Users/izzamasss/Documents/course/codewithbahri/fic14-custom/laravel-posresto-backend-jilid2/resources/views/components/auth-header.blade.php ENDPATH**/ ?>