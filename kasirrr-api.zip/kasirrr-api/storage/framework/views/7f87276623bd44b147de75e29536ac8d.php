 <div class="login-brand">
     <img src="<?php echo e(asset('img/skuy-group.png')); ?>" alt="logo" width="125" height="125" 
         class="shadow-light rounded-circle" style="padding: 15px;">
 </div>
<?php /**PATH /Users/izzamasss/Documents/work/skuy-project/dias-tugas/kasirrr-api/resources/views/components/auth-header.blade.php ENDPATH**/ ?>