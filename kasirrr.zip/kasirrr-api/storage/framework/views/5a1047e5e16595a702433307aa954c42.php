<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2024 <div class="bullet"></div> Design By <a href="https://jagoflutter.com/">JagoFlutter</a>
    </div>
    <div class="footer-right">
        1.0.0
    </div>
</footer>
<?php /**PATH /Users/izzamasss/Documents/course/codewithbahri/fic14-custom/laravel-posresto-backend-jilid2/resources/views/components/footer.blade.php ENDPATH**/ ?>