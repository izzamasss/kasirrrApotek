<?php $__env->startSection('title', 'Outlets'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/selectric/public/selectric.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Outlets</h1>
                <div class="section-header-button">
                    <a href="<?php echo e(route('outlets.create')); ?>" class="btn btn-primary">Add New</a>
                </div>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                    <div class="breadcrumb-item"><a href="#">Outlets</a></div>
                    <div class="breadcrumb-item">All Outlets</div>
                </div>
            </div>
            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <h2 class="section-title">Outlets</h2>

                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">

                            <div class="card-body">

                                <div class="float-right">
                                    <form method="GET" action="<?php echo e(route('outlets.index')); ?>">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Search" name="name">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <div class="clearfix mb-3"></div>

                                <div class="table-responsive">
                                    <table class="table-striped table">
                                        <tr style="text-align: center;">

                                            <th>Name</th>
                                            <th>Address</th>
                                            <th>City</th>
                                            <th>Province</th>
                                            <th>Notes</th>
                                            <th>Created At</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($outlet->name); ?>

                                                </td>
                                                <td> <?php echo e($outlet->address); ?></td>
                                                <td> <?php echo e($outlet->city); ?></td>
                                                <td> <?php echo e($outlet->province); ?></td>
                                                <td> <?php echo e($outlet->notes); ?></td>
                                                <td><?php echo e($outlet->created_at); ?></td>
                                                <td>
                                                    <div class="d-flex justify-content-center">
                                                        <a href='<?php echo e(route('outlets.index', 'outlet_id=' . $outlet->id)); ?>'
                                                            class="btn btn-sm btn-primary btn-icon">
                                                            <i class="fas fa-eye"></i>
                                                            User
                                                        </a>

                                                        <a href='<?php echo e(route('outlets.edit', $outlet->id)); ?>'
                                                            class="btn btn-sm btn-info btn-icon ml-2">
                                                            <i class="fas fa-edit"></i>
                                                            Edit
                                                        </a>

                                                        <form action="<?php echo e(route('outlets.destroy', $outlet->id)); ?>"
                                                            method="POST" class="ml-2">
                                                            <input type="hidden" name="_method" value="DELETE" />
                                                            <input type="hidden" name="_token"
                                                                value="<?php echo e(csrf_token()); ?>" />
                                                            <button class="btn btn-sm btn-danger btn-icon confirm-delete">
                                                                <i class="fas fa-times"></i> Delete
                                                            </button>
                                                        </form>

                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </table>
                                </div>
                                <div class="float-right">
                                    <?php echo e($outlets->withQueryString()->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        
        <?php if($isShowUser): ?>
        <section class="section">
            <div class="section-body">

                <h2 class="section-title">Outlets - Users</h2>



                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">


                            <div class="card-body">
                                <form action="<?php echo e(route('outlets-users.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="outlet_id" value="<?php echo e($outletId); ?>" />
                                    <div class="card-body">
                                        <label for="user_id" class="center">Add User</label>
                                        <div class="form-group row">
                                            <div class="col">
                                                <select
                                                    class="form-control selectric <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="user_id">
                                                    <option value="">Choose User</option>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> -
                                                            <?php echo e($user->email); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <button class="btn btn-primary col-sm-2">Submit</button>
                                        </div>
                                    </div>
                                </form>

                                <div class="table-responsive">
                                    <table class="table-striped table">
                                        <tr>

                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Created At</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php $__currentLoopData = $outletsUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($user->users->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($user->users->email); ?>

                                                </td>
                                                <td><?php echo e($user->users->created_at); ?></td>
                                                <td>
                                                    <div class="d-flex justify-content-center">
                                                        <form action="<?php echo e(route('outlets-users.destroy', $user->id)); ?>"
                                                            method="POST" class="ml-2">
                                                            <input type="hidden" name="_method" value="DELETE" />
                                                            <input type="hidden" name="_token"
                                                                value="<?php echo e(csrf_token()); ?>" />
                                                            <button class="btn btn-sm btn-danger btn-icon confirm-delete">
                                                                <i class="fas fa-times"></i> Delete
                                                            </button>
                                                        </form>

                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraies -->
    <script src="<?php echo e(asset('library/selectric/public/jquery.selectric.min.js')); ?>"></script>

    <!-- Page Specific JS File -->
    <script src="<?php echo e(asset('js/page/features-posts.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/izzamasss/Documents/work/skuy-project/skuy-api/resources/views/pages/outlets/index.blade.php ENDPATH**/ ?>