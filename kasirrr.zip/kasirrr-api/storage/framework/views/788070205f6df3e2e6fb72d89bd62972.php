<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">RESTO BAHRI</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">RB</a>
        </div>
        <ul class="sidebar-menu">



            <li class='nav-item'>
                <a class="nav-link" href="#"><i class="fas fa-columns"></i>General Dashboard</a>
            </li>



            <li class='nav-item'>
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>"><i class="fas fa-house-user"></i>Users</a>
            </li>




            <li class='nav-item'>
                <a class="nav-link" href="<?php echo e(route('products.index')); ?>"><i class="fas fa-product-hunt"></i>Products</a>
            </li>




            <li class='nav-item'>
                <a class="nav-link" href="<?php echo e(route('categories.index')); ?>"><i class="fas fa-sitemap"></i>Categories</a>
            </li>


            </li>

</div>
<?php /**PATH /Users/izzamasss/Documents/course/codewithbahri/fic14-custom/laravel-posresto-backend-jilid2/resources/views/components/sidebar.blade.php ENDPATH**/ ?>